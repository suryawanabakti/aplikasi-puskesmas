<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">

    <title>Puskesmas &mdash; Obat Keluar</title>
    <style>
        #customers {
            font-family: Arial, Helvetica, sans-serif;
            border-collapse: collapse;
            width: 100%;
        }

        #customers td,
        #customers th {
            border: 1px solid #ddd;
            padding: 8px;
        }

        #customers tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        #customers tr:hover {
            background-color: #ddd;
        }

        #customers th {
            padding-top: 12px;
            padding-bottom: 12px;
            text-align: left;
            background-color: #04AA6D;
            color: white;
        }
    </style>
</head>

<body>
    <div>
        <div style="text-align: center">
            <h6>PEMERINTAH KOTA PAREPARE <br> DINAS KESEHATAN <br>UPTD PUSKESMAS LUMPUE</h6>
            <small>Jl. H.A Iskandar No.2 Kec.Bacukiki Kel.Lumpue Kota Pare-pare</small>
        </div>

        <table id="customers">
            <thead>
                <tr>
                    <th>No.Invoice</th>
                    <th>Tanggal</th>
                    <th>Obat</th>
                    <th>Pasien</th>
                    <th>Jumlah</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $drugsOut; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($data->invoice); ?></td>
                        <td><?php echo e($data->tanggal_keluar); ?></td>
                        <td><?php echo e($data->obat->nama); ?></td>
                        <td><?php echo e($data->pasien->nama); ?></td>
                        <td><?php echo e($data->jumlah_keluar); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <table style="margin-top: 30px">
        <tr>
            <td width="500px">
                <div>
                    Penanggung Jawab Ruang Farmasi <br> <br> <br> <br> <br> <br>
                    <b>Nurhijarah H S.Farm. Apt</b>
                </div>
            </td>
            <td>
                <div>
                    Petugas Kesling <br> <br> <br> <br> <br> <br>
                    <b>ROSDIANA S.ST</b>
                </div>
            </td>
        </tr>
    </table>
    <div>


        <div class="" style="float:right; margin-right:150px">


        </div>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"
            integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous">
        </script>

</body>

</html>
<?php /**PATH C:\laragon\www\apoteker\resources\views/export/obatkeluar.blade.php ENDPATH**/ ?>